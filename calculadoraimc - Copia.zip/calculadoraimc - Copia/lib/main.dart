import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  build(context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(),
        home: const Casa(),
      );
}

class Casa extends StatefulWidget {
  const Casa({super.key});

  @override
  State createState() => HomeState();
}

class HomeState extends State {
  @override
  build(context) => Scaffold(
        appBar: AppBar(
          title: const Text("calculadora IMC"),
          centerTitle: true,
          actions: const <Widget>[Icon(Icons.notifications)],
        ),
        drawer: const Drawer(
          child: Text("Aprender a mecher aqui!!"),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(150.0),
            child: Column(
              children: <Widget>[
                const SizedBox(
                  height: 30.0,
                ),
                SizedBox(
                  width: 500,
                  child: TextFormField(
                    decoration: const InputDecoration(
                        labelText: "Digite o seu peso",
                        labelStyle: TextStyle(fontSize: 30),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(30)),
                        )),
                  ),
                ),
                const SizedBox(
                  height: 18.0,
                ),
                SizedBox(
                  width: 500,
                  child: TextFormField(
                    decoration: const InputDecoration(
                        labelText: "Digite a sua altura",
                        labelStyle: TextStyle(fontSize: 30),
                        border: OutlineInputBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(30)))),
                  ),
                ),
                const SizedBox(height: 18.0),
                ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(40)),
                      textStyle: const TextStyle(fontSize: 25)),
                  child: const Text("calcular"),
                )
              ],
            ),
          ),
        ),
      );
}
