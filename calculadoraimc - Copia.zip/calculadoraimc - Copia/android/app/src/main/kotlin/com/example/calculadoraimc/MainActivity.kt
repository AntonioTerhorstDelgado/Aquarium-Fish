package com.example.calculadoraimc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
